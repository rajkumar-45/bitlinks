import Link from 'next/link';
import { Link2, Twitter, Github, Linkedin, Mail } from "lucide-react";

const Footer = () => {
    return (
        <footer className="border-t border-white/[0.06] bg-white/[0.015] pt-16 pb-8 px-6 md:px-16">
            <div className="max-w-7xl mx-auto">
                <div className="grid grid-cols-1 md:grid-cols-5 gap-12 mb-12">
                    {/* Brand */}
                    <div className="md:col-span-2">
                        <Link href="/" className="flex items-center gap-2 mb-5 group w-fit">
                            <div className="bg-gradient-to-br from-purple-600 to-indigo-600 p-1.5 rounded-lg group-hover:rotate-12 transition-transform shadow-lg shadow-purple-500/20">
                                <Link2 className="w-5 h-5 text-white" />
                            </div>
                            <span className="text-2xl font-black text-gradient font-poppins">Bitlinks</span>
                        </Link>
                        <p className="text-muted-foreground text-sm leading-relaxed mb-6 max-w-xs">
                            The premium URL shortener for modern teams. Fast, secure, and packed with real-time analytics.
                        </p>
                        <div className="flex items-center gap-3">
                            {[
                                { Icon: Twitter, href: "#", label: "Twitter", hover: "hover:text-sky-400 hover:bg-sky-400/10" },
                                { Icon: Github, href: "#", label: "GitHub", hover: "hover:text-white hover:bg-white/10" },
                                { Icon: Linkedin, href: "#", label: "LinkedIn", hover: "hover:text-blue-400 hover:bg-blue-400/10" },
                                { Icon: Mail, href: "#", label: "Email", hover: "hover:text-purple-400 hover:bg-purple-400/10" },
                            ].map(({ Icon, href, label, hover }) => (
                                <a
                                    key={label}
                                    href={href}
                                    className={`p-2 rounded-xl text-muted-foreground border border-white/[0.06] transition-all ${hover}`}
                                    aria-label={label}
                                >
                                    <Icon className="w-4 h-4" />
                                </a>
                            ))}
                        </div>
                    </div>

                    {/* Links */}
                    {[
                        {
                            title: "Product",
                            links: [
                                { href: "/shorten", label: "URL Shortener" },
                                { href: "/dashboard", label: "Analytics" },
                                { href: "#", label: "API Access" },
                                { href: "#", label: "Pricing" },
                            ]
                        },
                        {
                            title: "Resources",
                            links: [
                                { href: "#", label: "Documentation" },
                                { href: "#", label: "Blog" },
                                { href: "/github", label: "GitHub" },
                                { href: "#", label: "Support" },
                            ]
                        },
                        {
                            title: "Legal",
                            links: [
                                { href: "/privacy", label: "Privacy Policy" },
                                { href: "/terms", label: "Terms of Service" },
                                { href: "#", label: "Cookie Policy" },
                            ]
                        }
                    ].map(({ title, links }) => (
                        <div key={title} className="flex flex-col gap-3">
                            <h4 className="font-bold text-sm uppercase tracking-wider text-muted-foreground mb-1">{title}</h4>
                            {links.map(({ href, label }) => (
                                <Link key={label} href={href} className="text-muted-foreground hover:text-purple-400 transition-colors text-sm">
                                    {label}
                                </Link>
                            ))}
                        </div>
                    ))}
                </div>

                <div className="border-t border-white/[0.06] pt-6 flex flex-col md:flex-row items-center justify-between gap-4">
                    <p className="text-muted-foreground text-sm text-center md:text-left">
                        &copy; {new Date().getFullYear()} Bitlinks. All rights reserved. Built with Next.js + MongoDB.
                    </p>
                    <div className="flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
                        <span className="text-xs text-muted-foreground font-medium">All systems operational</span>
                    </div>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
