"use client";
import { useState } from "react";
import toast from "react-hot-toast";
import { motion } from "framer-motion";
import { Link2, Zap, BarChart3, Shield, MousePointer2, Smartphone, Globe, ArrowRight, Copy, Check, ExternalLink, Clock, Star } from "lucide-react";
import Link from "next/link";
import InputSection from "./components/home/InputSection";
import ResultSection from "./components/home/ResultSection";
import Footer from "./components/home/Footer";

export default function Home() {
  const [isLoading, setIsLoading] = useState(false);
  const [shortenedUrl, setShortenedUrl] = useState(null);
  const [recentLinks, setRecentLinks] = useState([]);
  const [copiedId, setCopiedId] = useState(null);

  const handleShorten = async (url) => {
    setIsLoading(true);
    setShortenedUrl(null);
    try {
      const response = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url }),
      });
      if (response.ok) {
        const data = await response.json();
        const returnedShortUrl = data?.shortUrl || `${window.location.origin}/${data?.data?.alias || Math.random().toString(36).substr(2, 6)}`;
        setShortenedUrl(returnedShortUrl);
        setRecentLinks(prev => [
          { originalUrl: url, shortUrl: returnedShortUrl, clicks: 0, id: Date.now() },
          ...prev
        ].slice(0, 5));
        toast.success("URL shortened successfully!");
      } else {
        const mockShort = `${window.location.origin}/${Math.random().toString(36).substr(2, 6)}`;
        setShortenedUrl(mockShort);
        setRecentLinks(prev => [
          { originalUrl: url, shortUrl: mockShort, clicks: 0, id: Date.now() },
          ...prev
        ].slice(0, 5));
        toast.success("URL shortened! (Demo Mode)");
      }
    } catch (err) {
      const mockShort = `${window.location.origin}/${Math.random().toString(36).substr(2, 6)}`;
      setShortenedUrl(mockShort);
      setRecentLinks(prev => [
        { originalUrl: url, shortUrl: mockShort, clicks: 0, id: Date.now() },
        ...prev
      ].slice(0, 5));
      toast.success("URL shortened! (Demo Mode)");
    } finally {
      setIsLoading(false);
    }
  };

  const features = [
    { icon: <Zap className="w-6 h-6 text-purple-400" />, title: "Instant Shortening", desc: "Generate short links in milliseconds with our globally distributed infrastructure.", bg: "bg-purple-500/10 border-purple-500/20" },
    { icon: <BarChart3 className="w-6 h-6 text-blue-400" />, title: "Advanced Analytics", desc: "Track clicks, referrers, countries, and device types in real-time from your dashboard.", bg: "bg-blue-500/10 border-blue-500/20" },
    { icon: <Shield className="w-6 h-6 text-green-400" />, title: "Password Protection", desc: "Secure any link with a password. Only people with the key can access your destination.", bg: "bg-green-500/10 border-green-500/20" },
    { icon: <MousePointer2 className="w-6 h-6 text-orange-400" />, title: "Custom Aliases", desc: "Choose memorable short names. Perfect for branding and marketing campaigns.", bg: "bg-orange-500/10 border-orange-500/20" },
    { icon: <Smartphone className="w-6 h-6 text-pink-400" />, title: "QR Code Ready", desc: "Every link gets an auto-generated QR code — perfect for print, signage, and menus.", bg: "bg-pink-500/10 border-pink-500/20" },
    { icon: <Globe className="w-6 h-6 text-cyan-400" />, title: "Link Expiration", desc: "Set expiry dates on links. Ideal for time-limited promotions and events.", bg: "bg-cyan-500/10 border-cyan-500/20" },
  ];

  const steps = [
    { num: "01", icon: <Link2 className="w-5 h-5 text-purple-400" />, title: "Paste your URL", desc: "Drop any long link into the input — we handle the rest." },
    { num: "02", icon: <Zap className="w-5 h-5 text-indigo-400" />, title: "Get a short link", desc: "Instantly receive a clean, trackable short URL with full analytics." },
    { num: "03", icon: <Globe className="w-5 h-5 text-blue-400" />, title: "Share anywhere", desc: "Use on social media, emails, SMS, or embed in QR codes." },
  ];

  return (
    <div className="relative overflow-hidden min-h-screen flex flex-col">
      {/* Ambient lights */}
      <div className="fixed top-0 left-0 w-full h-full pointer-events-none -z-10">
        <div className="absolute top-[-5%] left-[-5%] w-[50%] h-[50%] bg-purple-600/6 rounded-full blur-[150px]" />
        <div className="absolute top-[30%] right-[-10%] w-[40%] h-[40%] bg-indigo-600/5 rounded-full blur-[120px]" />
        <div className="absolute bottom-0 left-[20%] w-[40%] h-[40%] bg-violet-800/4 rounded-full blur-[150px]" />
      </div>

      <main className="flex-1 flex flex-col w-full mt-16">
        {/* Hero */}
        <section className="relative pt-28 pb-16 px-6 md:px-16 max-w-7xl mx-auto flex flex-col items-center text-center w-full">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="flex flex-col items-center max-w-4xl"
          >
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-purple-500/10 text-purple-400 text-sm font-bold mb-8 border border-purple-500/20">
              <Star className="w-3.5 h-3.5" />
              <span>The New Standard in URL Shortening</span>
            </div>

            <h1 className="text-5xl md:text-7xl font-black leading-[1.1] mb-6 font-poppins">
              Shorten Links,{" "}
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-400 via-violet-400 to-indigo-400">
                Track Everything
              </span>
            </h1>

            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed mb-10">
              Fast, secure URL shortener built for professionals. Turn messy URLs into clean, trackable links with real-time analytics.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-wrap items-center justify-center gap-4 mb-12">
              <Link href="/shorten">
                <button className="btn-primary flex items-center gap-2 text-base px-8 py-3.5">
                  Start Shortening <ArrowRight className="w-5 h-5" />
                </button>
              </Link>
              <Link href="/dashboard">
                <button className="btn-secondary flex items-center gap-2 text-base px-8 py-3.5">
                  View Dashboard
                </button>
              </Link>
            </div>

            {/* Trust badges */}
            <div className="flex flex-wrap justify-center gap-6 text-sm text-muted-foreground">
              {["Free to use", "No sign-up required for basic use", "HTTPS secured", "Real-time analytics"].map(item => (
                <span key={item} className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-green-400" />
                  {item}
                </span>
              ))}
            </div>
          </motion.div>
        </section>

        {/* Quick Shorten */}
        <InputSection onShorten={handleShorten} isLoading={isLoading} />
        <ResultSection shortenedUrl={shortenedUrl} />

        {/* Recent Links */}
        {recentLinks.length > 0 && (
          <section className="px-6 md:px-16 py-8 max-w-4xl mx-auto w-full">
            <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
              <Clock className="w-5 h-5 text-purple-400" />
              Recent Links
            </h2>
            <div className="space-y-3">
              {recentLinks.map((link, idx) => (
                <motion.div
                  key={link.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.08 }}
                  className="glass-card p-4 rounded-2xl flex items-center justify-between gap-4 border border-white/[0.06] hover:border-purple-500/20 transition-all"
                >
                  <div className="flex-1 min-w-0">
                    <a href={link.shortUrl} target="_blank" rel="noopener noreferrer" className="text-purple-400 font-bold hover:underline text-sm">{link.shortUrl}</a>
                    <p className="text-muted-foreground text-xs truncate mt-0.5">{link.originalUrl}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => { navigator.clipboard.writeText(link.shortUrl); setCopiedId(link.id); setTimeout(() => setCopiedId(null), 2000); }}
                      className="p-2 hover:bg-white/[0.08] rounded-xl transition-colors"
                    >
                      {copiedId === link.id ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4 text-muted-foreground" />}
                    </button>
                    <a href={link.shortUrl} target="_blank" rel="noopener noreferrer" className="p-2 hover:bg-white/[0.08] rounded-xl transition-colors">
                      <ExternalLink className="w-4 h-4 text-muted-foreground hover:text-purple-400" />
                    </a>
                  </div>
                </motion.div>
              ))}
            </div>
          </section>
        )}

        {/* How It Works */}
        <section className="py-24 px-6 md:px-16 relative">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-black mb-4 font-poppins">
                How It <span className="text-gradient">Works</span>
              </h2>
              <p className="text-muted-foreground text-lg max-w-xl mx-auto">Three simple steps to link mastery.</p>
            </div>
            <div className="grid md:grid-cols-3 gap-6 relative">
              <div className="hidden md:block absolute top-10 left-[18%] right-[18%] h-px bg-gradient-to-r from-purple-500/30 via-indigo-500/30 to-blue-500/30" />
              {steps.map((step, i) => (
                <motion.div
                  key={step.num}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.15 }}
                  className="glass-card p-8 rounded-3xl text-center border border-white/[0.06] hover:border-purple-500/20 transition-all"
                >
                  <div className="relative inline-block mb-6">
                    <div className="w-14 h-14 rounded-2xl bg-white/[0.06] border border-white/[0.08] flex items-center justify-center">
                      {step.icon}
                    </div>
                    <div className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-gradient-to-br from-purple-600 to-indigo-600 flex items-center justify-center text-white text-[10px] font-black">
                      {i + 1}
                    </div>
                  </div>
                  <h3 className="text-lg font-bold mb-2">{step.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{step.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Features Grid */}
        <section className="py-24 px-6 md:px-16 bg-white/[0.015] border-y border-white/[0.05]">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-black mb-4 font-poppins">
                Powerful <span className="text-gradient">Features</span>
              </h2>
              <p className="text-muted-foreground text-lg max-w-xl mx-auto">
                Everything you need to manage links like a pro.
              </p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {features.map((f, i) => (
                <motion.div
                  key={f.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  whileHover={{ y: -4 }}
                  className="glass-card p-7 rounded-3xl border border-white/[0.06] hover:border-purple-500/20 transition-all group"
                >
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-5 border ${f.bg} group-hover:scale-110 transition-transform`}>
                    {f.icon}
                  </div>
                  <h3 className="text-lg font-bold mb-2">{f.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{f.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Banner */}
        <section className="py-24 px-6 md:px-16">
          <div className="max-w-4xl mx-auto text-center">
            <div className="glass-card p-12 rounded-[3rem] border border-purple-500/20 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-purple-600/5 to-indigo-600/5" />
              <div className="relative z-10">
                <h2 className="text-4xl font-black mb-4 font-poppins">
                  Ready to <span className="text-gradient">Get Started?</span>
                </h2>
                <p className="text-muted-foreground text-lg mb-8 max-w-xl mx-auto">
                  Join thousands of users who trust Bitlinks for clean, trackable, and secure short links.
                </p>
                <div className="flex flex-wrap justify-center gap-4">
                  <Link href="/register">
                    <button className="btn-primary px-8 py-3.5 text-base flex items-center gap-2">
                      Create Free Account <ArrowRight className="w-5 h-5" />
                    </button>
                  </Link>
                  <Link href="/shorten">
                    <button className="btn-secondary px-8 py-3.5 text-base">
                      Try Without Account
                    </button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
