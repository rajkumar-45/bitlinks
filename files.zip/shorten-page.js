"use client"
import Link from 'next/link'
import React, { useState } from 'react'
import localfont from "next/font/local";
import { Link as LinkIcon, Sparkles, Copy, Check, ArrowRight, Shield, Calendar, Lock, Zap, Loader2, QrCode, Share2, ExternalLink, Hash, Info } from "lucide-react";
import toast from "react-hot-toast";
import QRCode from 'qrcode';
import { motion } from "framer-motion";

const poppins = localfont({
    src: "../fonts/Poppins-ExtraBold.ttf",
    variable: "--font-Poppins",
    weight: "800",
});

const Shorten = () => {
    const [url, seturl] = useState("")
    const [shorturl, setshorturl] = useState("")
    const [expiresAt, setExpiresAt] = useState("")
    const [password, setPassword] = useState("")
    const [generated, setgenerated] = useState("")
    const [loading, setLoading] = useState(false)
    const [error, setError] = useState("")
    const [qrCode, setQrCode] = useState("")
    const [copied, setCopied] = useState(false)
    const [shortUrlSlug, setShortUrlSlug] = useState("")
    const [charCount, setCharCount] = useState(0)

    const generate = async () => {
        if (!url || !shorturl) {
            setError("Please enter both URL and short text!")
            return
        }
        if (!/^[a-zA-Z0-9-]+$/.test(shorturl)) {
            setError("Short text can only contain letters, numbers, and hyphens!")
            return
        }
        setError("")
        setLoading(true)
        const loadingToast = toast.loading("Creating your link...")

        try {
            const response = await fetch("/api/generate/", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    url,
                    shorturl,
                    expiresAt: expiresAt ? new Date(expiresAt).toISOString() : null,
                    password: password || null
                })
            })
            const result = await response.json()
            setLoading(false)

            if (result.success) {
                const fullUrl = `${window.location.protocol}//${window.location.host}/${shorturl}`
                setgenerated(fullUrl)
                setShortUrlSlug(shorturl)
                toast.success("Link generated!", { id: loadingToast })
                const qr = await QRCode.toDataURL(fullUrl, { color: { dark: '#8B5CF6', light: '#0a0a0f' } })
                setQrCode(qr)
                seturl("")
                setshorturl("")
                setExpiresAt("")
                setPassword("")
                setCharCount(0)
            } else {
                setError(result.message)
                toast.error(result.message, { id: loadingToast })
            }
        } catch (error) {
            setLoading(false)
            toast.error("Failed to generate link", { id: loadingToast })
            setError("An error occurred! Please try again.")
        }
    }

    const copyToClipboard = () => {
        navigator.clipboard.writeText(generated)
        setCopied(true)
        toast.success("Copied to clipboard!")
        setTimeout(() => setCopied(false), 2000)
    }

    const handleUrlChange = (e) => {
        seturl(e.target.value)
        setCharCount(e.target.value.length)
    }

    const autoGenerateSlug = () => {
        const slug = Math.random().toString(36).substring(2, 8)
        setshorturl(slug)
    }

    const shareLinks = [
        {
            label: "WhatsApp",
            href: `https://wa.me/?text=${encodeURIComponent("Check out: " + generated)}`,
            color: "bg-green-500/15 border-green-500/30 text-green-400 hover:bg-green-500/25",
            icon: (
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.446 4.432-9.877 9.881-9.877 2.64 0 5.122 1.028 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.446-4.435 9.877-9.883 9.877m8.415-18.293A11.085 11.085 0 0012.051 0C5.411 0 .007 5.405.005 12.046c0 2.123.554 4.197 1.604 6.04L0 24l6.105-1.602a11.037 11.037 0 005.41 1.405h.005c6.64 0 12.045-5.405 12.05-12.048a11.044 11.044 0 00-3.32-7.817" />
                </svg>
            )
        },
        {
            label: "X",
            href: `https://twitter.com/intent/tweet?text=${encodeURIComponent("Check out: " + generated)}`,
            color: "bg-white/10 border-white/20 text-white hover:bg-white/15",
            icon: (
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                </svg>
            )
        },
        {
            label: "Email",
            href: `mailto:?subject=${encodeURIComponent("Shared via Bitlinks")}&body=${encodeURIComponent("Check out: " + generated)}`,
            color: "bg-blue-500/15 border-blue-500/30 text-blue-400 hover:bg-blue-500/25",
            icon: (
                <svg className="w-4 h-4 fill-none stroke-current" viewBox="0 0 24 24" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M3 7a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7z" />
                    <path d="M3 7l9 6 9-6" />
                </svg>
            )
        }
    ]

    return (
        <div className='min-h-screen pt-32 pb-20 px-6 relative overflow-hidden'>
            {/* Background */}
            <div className="absolute top-40 -left-40 w-[500px] h-[500px] bg-purple-600/5 rounded-full blur-[120px] -z-10" />
            <div className="absolute bottom-20 -right-40 w-[500px] h-[500px] bg-indigo-600/5 rounded-full blur-[120px] -z-10" />
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-violet-900/5 rounded-full blur-[150px] -z-10" />

            <div className='max-w-2xl mx-auto'>
                {/* Header */}
                <div className='text-center mb-12'>
                    <div className='inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 text-purple-400 text-xs font-bold mb-4 border border-purple-500/20'>
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Instant Shortening</span>
                    </div>
                    <h1 className={`text-4xl md:text-5xl font-black mb-4 ${poppins.className}`}>
                        Create <span className="text-gradient">Magic Links</span>
                    </h1>
                    <p className='text-muted-foreground'>Customize, secure, and share your links in seconds.</p>
                </div>

                {/* Main Card */}
                <div className='glass p-8 md:p-10 rounded-[2.5rem] shadow-2xl relative overflow-hidden border border-white/[0.08]'>
                    <div className='absolute top-0 right-0 w-48 h-48 bg-purple-600/5 rounded-full -mr-24 -mt-24 blur-3xl' />

                    <div className='flex flex-col gap-6 relative z-10'>
                        {/* URL Input */}
                        <div className="space-y-2">
                            <label className="text-sm font-bold ml-2 uppercase tracking-wider text-muted-foreground flex items-center gap-2">
                                <LinkIcon className="w-4 h-4 text-purple-400" />
                                Destination URL
                            </label>
                            <div className="relative">
                                <input
                                    type="text"
                                    value={url}
                                    className='input-dark'
                                    placeholder='https://example.com/very-long-url-path'
                                    onChange={handleUrlChange}
                                />
                                {charCount > 0 && (
                                    <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xs text-muted-foreground font-mono">
                                        {charCount}
                                    </span>
                                )}
                            </div>
                        </div>

                        {/* Alias Input */}
                        <div className="space-y-2">
                            <label className="text-sm font-bold ml-2 uppercase tracking-wider text-muted-foreground flex items-center justify-between">
                                <span className="flex items-center gap-2">
                                    <Zap className="w-4 h-4 text-purple-400" />
                                    Custom Alias
                                </span>
                                <button
                                    type="button"
                                    onClick={autoGenerateSlug}
                                    className="text-xs text-purple-400 hover:text-purple-300 font-normal flex items-center gap-1 transition-colors"
                                >
                                    <Hash className="w-3 h-3" />
                                    Auto-generate
                                </button>
                            </label>
                            <div className="relative">
                                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground/50 font-medium text-sm">
                                    bitlinks.com/
                                </span>
                                <input
                                    type="text"
                                    value={shorturl}
                                    className='input-dark pl-[7.5rem]'
                                    placeholder='my-link'
                                    onChange={e => setshorturl(e.target.value)}
                                />
                            </div>
                            <p className="text-xs text-muted-foreground ml-2 flex items-center gap-1">
                                <Info className="w-3 h-3" />
                                Only letters, numbers, and hyphens allowed
                            </p>
                        </div>

                        {/* Advanced Options */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                            <div className="space-y-2">
                                <label className="text-xs font-bold ml-2 uppercase tracking-wider text-muted-foreground flex items-center gap-2">
                                    <Calendar className="w-3.5 h-3.5 text-blue-400" />
                                    Expiry Date (Optional)
                                </label>
                                <input
                                    type="date"
                                    value={expiresAt}
                                    className='input-dark py-3 text-sm [color-scheme:dark]'
                                    onChange={e => setExpiresAt(e.target.value)}
                                />
                            </div>
                            <div className="space-y-2">
                                <label className="text-xs font-bold ml-2 uppercase tracking-wider text-muted-foreground flex items-center gap-2">
                                    <Lock className="w-3.5 h-3.5 text-orange-400" />
                                    Password (Optional)
                                </label>
                                <input
                                    type="password"
                                    value={password}
                                    className='input-dark py-3 text-sm'
                                    placeholder="••••••••"
                                    onChange={e => setPassword(e.target.value)}
                                />
                            </div>
                        </div>

                        {/* Feature Tags */}
                        <div className="flex flex-wrap gap-2">
                            {[
                                { icon: <Shield className="w-3 h-3" />, label: "SSL Secured", color: "text-green-400 bg-green-500/10 border-green-500/20" },
                                { icon: <Zap className="w-3 h-3" />, label: "Real-time Analytics", color: "text-purple-400 bg-purple-500/10 border-purple-500/20" },
                                { icon: <QrCode className="w-3 h-3" />, label: "Auto QR Code", color: "text-blue-400 bg-blue-500/10 border-blue-500/20" },
                            ].map(({ icon, label, color }) => (
                                <span key={label} className={`inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full border ${color}`}>
                                    {icon}{label}
                                </span>
                            ))}
                        </div>

                        {error && (
                            <div className="bg-red-500/10 border border-red-500/20 text-red-400 text-xs font-bold px-4 py-3 rounded-xl text-center">
                                {error}
                            </div>
                        )}

                        <button
                            onClick={generate}
                            disabled={loading}
                            className='btn-primary w-full py-4 text-lg flex items-center justify-center gap-2 group/btn'
                        >
                            {loading
                                ? <Loader2 className="w-5 h-5 animate-spin" />
                                : <>Generate Link <ArrowRight className="w-5 h-5 group-hover/btn:translate-x-1 transition-transform" /></>
                            }
                        </button>
                    </div>

                    {/* Result */}
                    {generated && (
                        <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            className='mt-10 flex flex-col gap-6 pt-10 border-t border-white/[0.08]'
                        >
                            <div className='space-y-3'>
                                <p className='text-xs font-bold text-muted-foreground uppercase tracking-widest ml-1 flex items-center gap-2'>
                                    <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
                                    Link Created Successfully
                                </p>
                                <div className='flex items-center gap-2 bg-white/[0.04] border border-white/[0.08] p-2 rounded-2xl'>
                                    <div className="px-4 py-3 font-bold text-purple-400 truncate flex-1 text-sm">
                                        {generated}
                                    </div>
                                    <button
                                        onClick={copyToClipboard}
                                        className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white p-3 rounded-xl hover:scale-105 active:scale-95 transition-all shadow-lg shadow-purple-500/20"
                                        title="Copy Link"
                                    >
                                        {copied ? <Check className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
                                    </button>
                                    <a
                                        href={generated}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="bg-white/[0.08] border border-white/[0.12] text-white p-3 rounded-xl hover:scale-105 active:scale-95 transition-all"
                                        title="Visit Link"
                                    >
                                        <ExternalLink className="w-5 h-5" />
                                    </a>
                                </div>

                                {/* Share Buttons */}
                                <div className="space-y-2">
                                    <p className="text-xs text-muted-foreground ml-1 font-semibold uppercase tracking-wider flex items-center gap-1.5">
                                        <Share2 className="w-3 h-3" /> Share via
                                    </p>
                                    <div className="flex gap-2">
                                        {shareLinks.map(({ label, href, color, icon }) => (
                                            <a
                                                key={label}
                                                href={href}
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                className={`flex items-center gap-2 px-3 py-2 rounded-xl border text-xs font-bold transition-all hover:scale-105 active:scale-95 ${color}`}
                                                title={`Share on ${label}`}
                                            >
                                                {icon}
                                                {label}
                                            </a>
                                        ))}
                                    </div>
                                </div>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
                                <div className="space-y-3">
                                    {[
                                        { icon: <Shield className="w-4 h-4 text-green-400" />, bg: "bg-green-500/10", title: "Secure Redirect", sub: "HTTPS encryption enabled" },
                                        { icon: <Zap className="w-4 h-4 text-purple-400" />, bg: "bg-purple-500/10", title: "Real-time Tracking", sub: "Analytics now active" },
                                    ].map(({ icon, bg, title, sub }) => (
                                        <div key={title} className="flex items-center gap-3">
                                            <div className={`${bg} p-2 rounded-lg`}>{icon}</div>
                                            <div>
                                                <p className="text-sm font-bold">{title}</p>
                                                <p className="text-xs text-muted-foreground">{sub}</p>
                                            </div>
                                        </div>
                                    ))}
                                    <Link href="/dashboard" className="inline-block pt-1">
                                        <button className="text-sm font-bold text-purple-400 hover:text-purple-300 flex items-center gap-1 transition-colors">
                                            View in Dashboard <ArrowRight className="w-4 h-4" />
                                        </button>
                                    </Link>
                                </div>

                                {qrCode && (
                                    <div className="flex flex-col items-center gap-3 p-5 bg-white/[0.04] border border-white/[0.08] rounded-3xl">
                                        <img src={qrCode} alt="QR Code" className="w-32 h-32 rounded-xl border border-white/[0.1]" />
                                        <a
                                            href={qrCode}
                                            download={`qr-${shortUrlSlug}.png`}
                                            className="text-xs font-bold text-muted-foreground hover:text-purple-400 transition-colors flex items-center gap-1"
                                        >
                                            <QrCode className="w-3 h-3" /> Download QR
                                        </a>
                                    </div>
                                )}
                            </div>
                        </motion.div>
                    )}
                </div>

                <p className="text-center mt-8 text-sm text-muted-foreground">
                    By using Bitlinks, you agree to our{" "}
                    <Link href="/terms" className="underline underline-offset-4 font-semibold hover:text-purple-400 transition-colors">Terms</Link>
                    {" "}and{" "}
                    <Link href="/privacy" className="underline underline-offset-4 font-semibold hover:text-purple-400 transition-colors">Privacy Policy</Link>.
                </p>
            </div>
        </div>
    )
}

export default Shorten
