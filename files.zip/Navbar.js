"use client"
import Link from 'next/link';
import { useSession, signOut } from "next-auth/react";
import { User, LogOut, LayoutDashboard, Link as LinkIcon, Menu, X } from "lucide-react";
import { useState } from "react";

const Navbar = () => {
  const { data: session } = useSession();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 px-4 py-3">
      <div className="max-w-7xl mx-auto glass rounded-2xl px-5 py-3 flex justify-between items-center border border-white/[0.08]">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 group">
          <div className="bg-gradient-to-br from-[#8B5CF6] to-[#6366F1] p-1.5 rounded-lg group-hover:rotate-12 transition-transform shadow-lg shadow-purple-500/20">
            <LinkIcon className="w-5 h-5 text-white" />
          </div>
          <div className="text-2xl font-black text-gradient font-poppins">
            Bitlinks
          </div>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex gap-6 items-center">
          {[
            { href: "/", label: "Home" },
            { href: "/shorten", label: "Shorten" },
            { href: "/dashboard", label: "Analytics" },
            { href: "/github", label: "GitHub" },
          ].map(({ href, label }) => (
            <Link key={href} href={href} className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors hover:text-[#8B5CF6]">
              {label}
            </Link>
          ))}
        </div>

        {/* Auth */}
        <div className="flex gap-3 items-center">
          {session ? (
            <div className="flex gap-2 items-center border-l border-white/10 pl-4">
              <Link href="/dashboard" className="p-2 rounded-xl text-muted-foreground hover:bg-white/[0.08] transition-colors" title="Dashboard">
                <LayoutDashboard className="w-5 h-5" />
              </Link>
              <div className="hidden md:flex items-center gap-2 bg-white/[0.06] border border-white/[0.08] px-3 py-1.5 rounded-xl">
                <div className="w-5 h-5 rounded-full bg-gradient-to-br from-purple-500 to-indigo-500 flex items-center justify-center text-white text-xs font-bold">
                  {session.user.name?.[0]?.toUpperCase()}
                </div>
                <span className="text-sm font-semibold truncate max-w-[100px]">{session.user.name}</span>
              </div>
              <button
                onClick={() => signOut()}
                className="p-2 rounded-xl text-muted-foreground hover:text-red-400 hover:bg-red-500/10 transition-colors"
                title="Logout"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          ) : (
            <div className="flex gap-3 items-center border-l border-white/10 pl-4">
              <Link href="/login" className="text-sm font-semibold text-muted-foreground hover:text-[#8B5CF6] transition-colors hidden md:block">
                Login
              </Link>
              <Link href="/register">
                <button className="btn-primary py-2 px-4 text-sm">
                  Get Started
                </button>
              </Link>
            </div>
          )}

          {/* Mobile toggle */}
          <button
            className="md:hidden p-2 rounded-xl text-muted-foreground hover:bg-white/[0.08] transition-colors ml-1"
            onClick={() => setMobileOpen(!mobileOpen)}
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="md:hidden max-w-7xl mx-auto mt-2 glass rounded-2xl px-5 py-4 border border-white/[0.08] flex flex-col gap-3">
          {[
            { href: "/", label: "Home" },
            { href: "/shorten", label: "Shorten" },
            { href: "/dashboard", label: "Analytics" },
            { href: "/github", label: "GitHub" },
          ].map(({ href, label }) => (
            <Link key={href} href={href} onClick={() => setMobileOpen(false)} className="text-sm font-medium text-muted-foreground hover:text-[#8B5CF6] transition-colors py-1">
              {label}
            </Link>
          ))}
          {!session && (
            <Link href="/login" onClick={() => setMobileOpen(false)} className="text-sm font-medium text-muted-foreground hover:text-[#8B5CF6] transition-colors py-1">
              Login
            </Link>
          )}
        </div>
      )}
    </nav>
  );
};

export default Navbar;
