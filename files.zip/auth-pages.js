// ============================================================
// FILE: app/login/page.js
// ============================================================
"use client"
import { useState } from "react"
import { signIn } from "next-auth/react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Mail, Lock, Loader2, Link2, ArrowRight } from "lucide-react"

export default function LoginPage() {
    const [email, setEmail] = useState("")
    const [password, setPassword] = useState("")
    const [error, setError] = useState("")
    const [loading, setLoading] = useState(false)
    const router = useRouter()

    const handleSubmit = async (e) => {
        e.preventDefault()
        setLoading(true)
        setError("")
        try {
            const res = await signIn("credentials", {
                email: email.toLowerCase(),
                password,
                redirect: false
            })
            if (res.error) {
                setError("Invalid email or password")
            } else {
                router.push("/dashboard")
                router.refresh()
            }
        } catch (err) {
            setError("Something went wrong")
        } finally {
            setLoading(false)
        }
    }

    return (
        <div className="min-h-screen flex items-center justify-center p-4 pb-20 relative overflow-hidden">
            <div className="absolute top-20 -left-20 w-80 h-80 bg-purple-600/8 rounded-full blur-[120px] -z-10" />
            <div className="absolute bottom-20 -right-20 w-80 h-80 bg-indigo-600/6 rounded-full blur-[120px] -z-10" />

            <div className="w-full max-w-md">
                {/* Logo */}
                <div className="flex justify-center mb-8">
                    <Link href="/" className="flex items-center gap-2 group">
                        <div className="bg-gradient-to-br from-purple-600 to-indigo-600 p-2 rounded-xl group-hover:rotate-12 transition-transform shadow-lg shadow-purple-500/20">
                            <Link2 className="w-5 h-5 text-white" />
                        </div>
                        <span className="text-2xl font-black text-gradient font-poppins">Bitlinks</span>
                    </Link>
                </div>

                <div className="glass border border-white/[0.08] rounded-3xl p-8">
                    <div className="text-center mb-8">
                        <h1 className="text-2xl font-black mb-2">Welcome back</h1>
                        <p className="text-muted-foreground text-sm">Sign in to your account to continue</p>
                    </div>

                    <form onSubmit={handleSubmit} className="flex flex-col gap-4">
                        <div className="space-y-1.5">
                            <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground ml-1 flex items-center gap-1.5">
                                <Mail className="w-3.5 h-3.5" /> Email
                            </label>
                            <input
                                type="email"
                                placeholder="you@example.com"
                                className="input-dark"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                required
                            />
                        </div>
                        <div className="space-y-1.5">
                            <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground ml-1 flex items-center gap-1.5">
                                <Lock className="w-3.5 h-3.5" /> Password
                            </label>
                            <input
                                type="password"
                                placeholder="••••••••"
                                className="input-dark"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                required
                            />
                        </div>

                        {error && (
                            <div className="bg-red-500/10 border border-red-500/20 text-red-400 text-xs font-bold px-4 py-3 rounded-xl text-center">
                                {error}
                            </div>
                        )}

                        <button
                            type="submit"
                            disabled={loading}
                            className="btn-primary w-full py-3.5 flex items-center justify-center gap-2 mt-2"
                        >
                            {loading ? <Loader2 className="animate-spin w-5 h-5" /> : <>Sign In <ArrowRight className="w-4 h-4" /></>}
                        </button>
                    </form>

                    <p className="text-center mt-6 text-muted-foreground text-sm">
                        Don't have an account?{" "}
                        <Link href="/register" className="text-purple-400 font-bold hover:text-purple-300 transition-colors">
                            Register free
                        </Link>
                    </p>
                </div>
            </div>
        </div>
    )
}

// ============================================================
// FILE: app/register/page.js
// ============================================================
// "use client"
// import { useState } from "react"
// import { useRouter } from "next/navigation"
// import Link from "next/link"
// import { User, Mail, Lock, Loader2, Link2, ArrowRight } from "lucide-react"
//
// export default function RegisterPage() {
//     const [name, setName] = useState("")
//     const [email, setEmail] = useState("")
//     const [password, setPassword] = useState("")
//     const [error, setError] = useState("")
//     const [loading, setLoading] = useState(false)
//     const router = useRouter()
//
//     const handleSubmit = async (e) => {
//         e.preventDefault()
//         setLoading(true)
//         setError("")
//         try {
//             const res = await fetch("/api/register", {
//                 method: "POST",
//                 headers: { "Content-Type": "application/json" },
//                 body: JSON.stringify({ name, email, password })
//             })
//             const data = await res.json()
//             if (data.success) {
//                 router.push("/login?registered=true")
//             } else {
//                 setError(data.message || "Registration failed")
//             }
//         } catch (err) {
//             setError("Something went wrong")
//         } finally {
//             setLoading(false)
//         }
//     }
//
//     return (
//         <div className="min-h-screen flex items-center justify-center p-4 pb-20 relative overflow-hidden">
//             <div className="absolute top-20 -left-20 w-80 h-80 bg-purple-600/8 rounded-full blur-[120px] -z-10" />
//             <div className="w-full max-w-md">
//                 <div className="flex justify-center mb-8">
//                     <Link href="/" className="flex items-center gap-2 group">
//                         <div className="bg-gradient-to-br from-purple-600 to-indigo-600 p-2 rounded-xl group-hover:rotate-12 transition-transform">
//                             <Link2 className="w-5 h-5 text-white" />
//                         </div>
//                         <span className="text-2xl font-black text-gradient font-poppins">Bitlinks</span>
//                     </Link>
//                 </div>
//                 <div className="glass border border-white/[0.08] rounded-3xl p-8">
//                     <div className="text-center mb-8">
//                         <h1 className="text-2xl font-black mb-2">Create account</h1>
//                         <p className="text-muted-foreground text-sm">Start shortening links for free</p>
//                     </div>
//                     <form onSubmit={handleSubmit} className="flex flex-col gap-4">
//                         ...inputs same style as login...
//                         <button type="submit" disabled={loading} className="btn-primary w-full py-3.5 flex items-center justify-center gap-2 mt-2">
//                             {loading ? <Loader2 className="animate-spin w-5 h-5" /> : <>Create Account <ArrowRight className="w-4 h-4" /></>}
//                         </button>
//                     </form>
//                     <p className="text-center mt-6 text-muted-foreground text-sm">
//                         Already have an account? <Link href="/login" className="text-purple-400 font-bold hover:text-purple-300">Sign in</Link>
//                     </p>
//                 </div>
//             </div>
//         </div>
//     )
// }
