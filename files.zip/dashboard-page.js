"use client"
import { useState, useEffect, useMemo } from "react"
import { useSession } from "next-auth/react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Trash2, ExternalLink, QrCode, Copy, Check, Plus, Edit3, Loader2, MousePointer2, Link as LinkIcon, BarChart, Zap, Lock, Calendar, Search, Filter, SortAsc, Globe, Smartphone, TrendingUp, Activity } from "lucide-react"
import toast from "react-hot-toast"
import QRCode from 'qrcode'
import AnalyticsChart from "../components/AnalyticsChart"

export default function Dashboard() {
    const { data: session, status } = useSession()
    const router = useRouter()
    const [links, setLinks] = useState([])
    const [stats, setStats] = useState({ totalLinks: 0, totalClicks: 0, topLink: null })
    const [loading, setLoading] = useState(true)
    const [copiedId, setCopiedId] = useState(null)
    const [searchQuery, setSearchQuery] = useState("")
    const [sortBy, setSortBy] = useState("newest")
    const [filterActive, setFilterActive] = useState("all")

    useEffect(() => {
        if (status === "unauthenticated") router.push("/login")
        else if (status === "authenticated") fetchLinks()
    }, [status])

    const fetchLinks = async () => {
        try {
            const res = await fetch("/api/links")
            const data = await res.json()
            if (data.success) {
                setLinks(data.links)
                setStats(data.stats)
            }
        } catch (error) {
            toast.error("Failed to fetch links")
        } finally {
            setLoading(false)
        }
    }

    const filteredLinks = useMemo(() => {
        let result = [...links]

        if (searchQuery) {
            result = result.filter(l =>
                l.shorturl.toLowerCase().includes(searchQuery.toLowerCase()) ||
                l.url.toLowerCase().includes(searchQuery.toLowerCase())
            )
        }

        if (filterActive === "active") result = result.filter(l => l.isActive !== false)
        if (filterActive === "inactive") result = result.filter(l => l.isActive === false)
        if (filterActive === "password") result = result.filter(l => !!l.password)
        if (filterActive === "expiring") result = result.filter(l => !!l.expiresAt)

        if (sortBy === "newest") result.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
        if (sortBy === "oldest") result.sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt))
        if (sortBy === "most-clicks") result.sort((a, b) => (b.clicks || 0) - (a.clicks || 0))
        if (sortBy === "least-clicks") result.sort((a, b) => (a.clicks || 0) - (b.clicks || 0))

        return result
    }, [links, searchQuery, sortBy, filterActive])

    const deleteLink = async (id) => {
        if (!confirm("Are you sure you want to delete this link?")) return
        const loadingToast = toast.loading("Deleting link...")
        try {
            const res = await fetch(`/api/links?id=${id}`, { method: "DELETE" })
            const data = await res.json()
            if (data.success) {
                setLinks(links.filter(link => link._id !== id))
                toast.success("Link deleted successfully", { id: loadingToast })
            } else {
                toast.error(data.message, { id: loadingToast })
            }
        } catch (error) {
            toast.error("Failed to delete link", { id: loadingToast })
        }
    }

    const copyToClipboard = (shortUrl) => {
        const fullUrl = `${window.location.origin}/${shortUrl}`
        navigator.clipboard.writeText(fullUrl)
        setCopiedId(shortUrl)
        toast.success("Copied to clipboard!")
        setTimeout(() => setCopiedId(null), 2000)
    }

    const editLink = async (id, currentUrl) => {
        const newUrl = prompt("Enter new destination URL:", currentUrl)
        if (!newUrl || newUrl === currentUrl) return
        const loadingToast = toast.loading("Updating link...")
        try {
            const res = await fetch("/api/links", {
                method: "PATCH",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ id, newUrl })
            })
            const data = await res.json()
            if (data.success) {
                const formattedUrl = newUrl.startsWith('http') ? newUrl : 'https://' + newUrl
                setLinks(links.map(link => link._id === id ? { ...link, url: formattedUrl } : link))
                toast.success("Link updated successfully", { id: loadingToast })
            } else {
                toast.error(data.message, { id: loadingToast })
            }
        } catch (error) {
            toast.error("Failed to update link", { id: loadingToast })
        }
    }

    const toggleStatus = async (id, currentStatus) => {
        const loadingToast = toast.loading(`${currentStatus ? "Deactivating" : "Activating"} link...`)
        try {
            const res = await fetch("/api/links", {
                method: "PATCH",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ id, isActive: !currentStatus })
            })
            const data = await res.json()
            if (data.success) {
                setLinks(links.map(link => link._id === id ? { ...link, isActive: !currentStatus } : link))
                toast.success(`Link ${!currentStatus ? "activated" : "deactivated"}`, { id: loadingToast })
            } else {
                toast.error(data.message, { id: loadingToast })
            }
        } catch (error) {
            toast.error("Failed to update status", { id: loadingToast })
        }
    }

    if (status === "loading" || loading) {
        return (
            <div className="flex flex-col justify-center items-center min-h-[60vh] gap-4">
                <div className="relative w-16 h-16">
                    <div className="absolute inset-0 rounded-full border-2 border-purple-500/20 animate-ping" />
                    <div className="absolute inset-2 rounded-full bg-gradient-to-br from-purple-600 to-indigo-600 flex items-center justify-center">
                        <Loader2 className="w-6 h-6 text-white animate-spin" />
                    </div>
                </div>
                <p className="text-muted-foreground font-medium animate-pulse">Loading your dashboard...</p>
            </div>
        )
    }

    const ctr = stats.totalLinks > 0 ? ((stats.totalClicks / stats.totalLinks)).toFixed(1) : "0"

    return (
        <div className="max-w-7xl mx-auto px-6 py-12">
            {/* Background */}
            <div className="fixed top-0 left-0 w-full h-full pointer-events-none -z-10">
                <div className="absolute top-20 left-10 w-96 h-96 bg-purple-600/5 rounded-full blur-[120px]" />
                <div className="absolute bottom-20 right-10 w-96 h-96 bg-indigo-600/5 rounded-full blur-[120px]" />
            </div>

            {/* Header */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12">
                <div>
                    <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-purple-500/10 text-purple-400 text-xs font-bold mb-3 border border-purple-500/20">
                        <Activity className="w-3 h-3" />
                        Live Dashboard
                    </div>
                    <h1 className="text-4xl font-black mb-1">Analytics Hub</h1>
                    <p className="text-muted-foreground">Manage, track, and optimize your shortened links.</p>
                </div>
                <Link href="/shorten">
                    <button className="btn-primary flex items-center gap-2">
                        <Plus className="w-5 h-5" />
                        New Link
                    </button>
                </Link>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
                {[
                    { icon: <LinkIcon className="w-5 h-5" />, label: "Total Links", value: stats.totalLinks, color: "text-purple-400", bg: "bg-purple-500/10 border-purple-500/20" },
                    { icon: <MousePointer2 className="w-5 h-5" />, label: "Total Clicks", value: stats.totalClicks, color: "text-blue-400", bg: "bg-blue-500/10 border-blue-500/20" },
                    { icon: <TrendingUp className="w-5 h-5" />, label: "Avg Clicks/Link", value: ctr, color: "text-green-400", bg: "bg-green-500/10 border-green-500/20" },
                    { icon: <BarChart className="w-5 h-5" />, label: "Best Link", value: stats.topLink ? `/${stats.topLink.shorturl}` : "N/A", color: "text-orange-400", bg: "bg-orange-500/10 border-orange-500/20", sub: stats.topLink ? `${stats.topLink.clicks} clicks` : "" },
                ].map(({ icon, label, value, color, bg, sub }) => (
                    <div key={label} className="glass-card p-5 rounded-2xl border border-white/[0.06]">
                        <div className={`inline-flex p-2 rounded-xl ${bg} border mb-3`}>
                            <span className={color}>{icon}</span>
                        </div>
                        <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-1">{label}</p>
                        <div className="flex items-baseline gap-1.5">
                            <span className="text-2xl font-black truncate">{value}</span>
                            {sub && <span className={`text-xs font-bold ${color}`}>{sub}</span>}
                        </div>
                    </div>
                ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Link List */}
                <div className="lg:col-span-2 space-y-4">
                    {/* Search & Filter */}
                    <div className="flex flex-col sm:flex-row gap-3 mb-6">
                        <div className="relative flex-1">
                            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                            <input
                                type="text"
                                value={searchQuery}
                                onChange={e => setSearchQuery(e.target.value)}
                                placeholder="Search links..."
                                className="input-dark pl-11 py-3 text-sm"
                            />
                        </div>
                        <select
                            value={filterActive}
                            onChange={e => setFilterActive(e.target.value)}
                            className="input-dark py-3 text-sm w-full sm:w-auto bg-[hsl(217,33%,14%)] cursor-pointer"
                        >
                            <option value="all">All Links</option>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                            <option value="password">Password Protected</option>
                            <option value="expiring">Has Expiry</option>
                        </select>
                        <select
                            value={sortBy}
                            onChange={e => setSortBy(e.target.value)}
                            className="input-dark py-3 text-sm w-full sm:w-auto bg-[hsl(217,33%,14%)] cursor-pointer"
                        >
                            <option value="newest">Newest First</option>
                            <option value="oldest">Oldest First</option>
                            <option value="most-clicks">Most Clicks</option>
                            <option value="least-clicks">Least Clicks</option>
                        </select>
                    </div>

                    <div className="flex items-center justify-between mb-2">
                        <h2 className="text-lg font-bold flex items-center gap-2">
                            Links
                            <span className="text-xs font-normal bg-white/[0.08] border border-white/[0.1] px-2 py-0.5 rounded-full text-muted-foreground">
                                {filteredLinks.length} of {links.length}
                            </span>
                        </h2>
                    </div>

                    {filteredLinks.length === 0 ? (
                        <div className="glass-card p-20 text-center rounded-[2rem] border border-white/[0.06]">
                            <div className="bg-white/[0.06] border border-white/[0.08] w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6">
                                <LinkIcon className="w-8 h-8 text-muted-foreground" />
                            </div>
                            <h3 className="text-xl font-bold mb-2">{searchQuery ? "No results found" : "No links yet"}</h3>
                            <p className="text-muted-foreground mb-8 text-balance text-sm">
                                {searchQuery ? "Try a different search term." : "Create your first shortened link to get started."}
                            </p>
                            {!searchQuery && (
                                <Link href="/shorten">
                                    <button className="btn-primary text-sm">Create Link</button>
                                </Link>
                            )}
                        </div>
                    ) : (
                        filteredLinks.map((link) => (
                            <LinkItem
                                key={link._id}
                                link={link}
                                onCopy={() => copyToClipboard(link.shorturl)}
                                onEdit={() => editLink(link._id, link.url)}
                                onDelete={() => deleteLink(link._id)}
                                onToggle={() => toggleStatus(link._id, link.isActive !== false)}
                                copiedId={copiedId}
                            />
                        ))
                    )}
                </div>

                {/* Analytics Sidebar */}
                <div className="space-y-6">
                    <div className="glass-card p-6 rounded-3xl sticky top-32 border border-white/[0.06]">
                        <h2 className="text-lg font-bold mb-1">Click Trends</h2>
                        <p className="text-xs text-muted-foreground mb-6">Last 7 days performance</p>
                        <AnalyticsChart statsData={stats.history} />

                        <div className="mt-6 pt-6 border-t border-white/[0.06]">
                            <h3 className="font-bold mb-4 flex items-center gap-2">
                                <Globe className="w-4 h-4 text-purple-400" />
                                Top Countries
                            </h3>
                            <div className="space-y-3">
                                {stats.countries && stats.countries.length > 0 ? (
                                    stats.countries.map((c, i) => (
                                        <ReferrerItem
                                            key={i}
                                            label={c.label}
                                            value={`${Math.round((c.count / stats.totalClicks) * 100) || 0}%`}
                                            color={["bg-purple-500", "bg-indigo-500", "bg-blue-500"][i] || "bg-slate-500"}
                                        />
                                    ))
                                ) : (
                                    <p className="text-xs text-muted-foreground italic">No click data yet</p>
                                )}
                            </div>
                        </div>

                        <div className="mt-6 pt-6 border-t border-white/[0.06]">
                            <h3 className="font-bold mb-4 flex items-center gap-2">
                                <Smartphone className="w-4 h-4 text-blue-400" />
                                Device Types
                            </h3>
                            <div className="space-y-3">
                                {stats.devices && stats.devices.length > 0 ? (
                                    stats.devices.map((d, i) => (
                                        <ReferrerItem
                                            key={i}
                                            label={d.label}
                                            value={`${Math.round((d.count / stats.totalClicks) * 100) || 0}%`}
                                            color="bg-slate-500"
                                        />
                                    ))
                                ) : (
                                    <p className="text-xs text-muted-foreground italic">No device data yet</p>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

function LinkItem({ link, onCopy, onEdit, onDelete, onToggle, copiedId }) {
    const isExpired = link.expiresAt && new Date(link.expiresAt) < new Date()
    const isActive = link.isActive !== false

    return (
        <div className={`glass-card p-5 rounded-2xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border border-white/[0.06] hover:border-purple-500/20 transition-all group ${!isActive || isExpired ? 'opacity-50 saturate-0' : ''}`}>
            <div className="flex-1 min-w-0 w-full">
                <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                    <span className="text-purple-400 font-black text-lg hover:underline cursor-pointer">
                        /{link.shorturl}
                    </span>
                    <div className="flex items-center gap-1.5">
                        {link.password && (
                            <span className="inline-flex items-center gap-1 text-[10px] bg-orange-500/10 text-orange-400 border border-orange-500/20 px-1.5 py-0.5 rounded-md font-bold uppercase">
                                <Lock className="w-2.5 h-2.5" /> Protected
                            </span>
                        )}
                        {link.expiresAt && (
                            <span className="inline-flex items-center gap-1 text-[10px] bg-blue-500/10 text-blue-400 border border-blue-500/20 px-1.5 py-0.5 rounded-md font-bold uppercase">
                                <Calendar className="w-2.5 h-2.5" /> Expires
                            </span>
                        )}
                        {isExpired && (
                            <span className="text-[10px] bg-red-500/10 text-red-400 border border-red-500/20 px-1.5 py-0.5 rounded-md font-bold uppercase">Expired</span>
                        )}
                        {!isActive && (
                            <span className="text-[10px] bg-white/[0.06] text-muted-foreground border border-white/[0.08] px-1.5 py-0.5 rounded-md font-bold uppercase">Inactive</span>
                        )}
                    </div>
                </div>
                <div className="flex items-center gap-2">
                    <p className="text-muted-foreground text-sm truncate max-w-xs">{link.url}</p>
                    <button onClick={onCopy} className="p-1 hover:bg-white/[0.08] rounded-lg transition-colors flex-shrink-0" title="Copy">
                        {copiedId === link.shorturl ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5 text-muted-foreground" />}
                    </button>
                    <a href={`/${link.shorturl}`} target="_blank" rel="noopener noreferrer" className="p-1 hover:bg-white/[0.08] rounded-lg transition-colors flex-shrink-0">
                        <ExternalLink className="w-3.5 h-3.5 text-muted-foreground hover:text-purple-400" />
                    </a>
                </div>
            </div>

            <div className="flex items-center gap-6 w-full md:w-auto border-t md:border-t-0 border-white/[0.06] pt-3 md:pt-0">
                <div className="flex flex-col items-center">
                    <span className="text-[10px] text-muted-foreground uppercase font-black tracking-widest mb-0.5">Clicks</span>
                    <span className="text-xl font-black text-foreground">{link.clicks || 0}</span>
                </div>

                <div className="flex gap-1 ml-auto">
                    <button onClick={onToggle}
                        className={`p-2 rounded-xl transition-all ${isActive ? 'text-green-400 hover:bg-green-500/10' : 'text-muted-foreground hover:bg-white/[0.08]'}`}
                        title={isActive ? "Deactivate" : "Activate"}
                    >
                        <Zap className="w-4 h-4" fill={isActive ? "currentColor" : "transparent"} />
                    </button>
                    <button onClick={onEdit} className="p-2 text-muted-foreground hover:text-purple-400 hover:bg-purple-500/10 rounded-xl transition-all" title="Edit">
                        <Edit3 className="w-4 h-4" />
                    </button>
                    <button
                        onClick={() => {
                            const fullUrl = `${window.location.protocol}//${window.location.host}/${link.shorturl}`
                            QRCode.toDataURL(fullUrl, { color: { dark: '#8B5CF6', light: '#0a0a0f' } }).then(qr => {
                                toast((t) => (
                                    <div className="flex flex-col items-center gap-3 p-2">
                                        <p className="font-bold text-sm">QR Code for /{link.shorturl}</p>
                                        <img src={qr} className="w-44 h-44 border border-white/10 rounded-xl" />
                                        <button onClick={() => toast.dismiss(t.id)} className="btn-primary py-1.5 px-4 text-xs w-full">Close</button>
                                    </div>
                                ), { duration: 8000 })
                            })
                        }}
                        className="p-2 text-muted-foreground hover:text-blue-400 hover:bg-blue-500/10 rounded-xl transition-all"
                        title="QR Code"
                    >
                        <QrCode className="w-4 h-4" />
                    </button>
                    <button onClick={onDelete} className="p-2 text-muted-foreground hover:text-red-400 hover:bg-red-500/10 rounded-xl transition-all" title="Delete">
                        <Trash2 className="w-4 h-4" />
                    </button>
                </div>
            </div>
        </div>
    )
}

function ReferrerItem({ label, value, color }) {
    return (
        <div className="space-y-1">
            <div className="flex justify-between text-xs font-bold uppercase tracking-wider">
                <span className="text-muted-foreground">{label || "Unknown"}</span>
                <span>{value}</span>
            </div>
            <div className="h-1 w-full bg-white/[0.06] rounded-full overflow-hidden">
                <div className={`h-full ${color} rounded-full transition-all`} style={{ width: value }} />
            </div>
        </div>
    )
}
